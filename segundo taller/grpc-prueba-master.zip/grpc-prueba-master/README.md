
Install deps

```
pip3 install grpcio
pip3 install grpcio-tools
```

run
```	
  python3 src/cliente.py
  python3 src/server.py
  python3 src/op1.py
  python3 src/op2.py
  python3 src/op3.py
```
